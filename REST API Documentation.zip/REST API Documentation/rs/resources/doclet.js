targetPage = "" + window.location.search;
    if (targetPage != "" && targetPage != "undefined")
        targetPage = targetPage.substring(1);

    function loadFrames() {
        if (targetPage != "" && targetPage != "undefined")
             top.contentFrame.location = top.targetPage;
    }